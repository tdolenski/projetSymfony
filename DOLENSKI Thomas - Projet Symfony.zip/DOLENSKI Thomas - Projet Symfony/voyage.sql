-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : Dim 08 mars 2020 à 17:33
-- Version du serveur :  10.4.11-MariaDB
-- Version de PHP : 7.4.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `voyage`
--

-- --------------------------------------------------------

--
-- Structure de la table `article`
--

CREATE TABLE `article` (
  `id` int(11) NOT NULL,
  `continent_id_id` int(11) DEFAULT NULL,
  `name_article` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `article`
--

INSERT INTO `article` (`id`, `continent_id_id`, `name_article`, `description`, `image`) VALUES
(1, 22, 'Dolorem est excepturi repellendus.', 'Fugit et vel et et sit nemo officiis. Alias nisi quis et odio ut. Voluptatem laudantium veritatis expedita at assumenda tempore non saepe. Et ratione facere ullam accusantium.', 'images.jpg'),
(2, 22, 'Non numquam.', 'Ab facilis itaque excepturi quos. Est temporibus sed repellendus enim. Ut earum et ducimus laudantium nisi quidem vitae sit.', 'images.jpg'),
(3, 22, 'Delectus est dolor quidem iste.', 'Praesentium dolor temporibus corrupti. Iste velit consequatur provident magnam et rerum et qui. Enim facilis quasi fugiat. Est atque quo ad sed dolores corporis.', 'images.jpg'),
(4, 21, 'Tempora nihil magni sit et.', 'Id cupiditate maiores nisi esse dolore inventore. Ad repudiandae libero nihil modi. Odio distinctio non voluptatum reiciendis impedit explicabo.', 'images.jpg'),
(5, 24, 'Voluptas magni nisi recusandae.', 'In accusamus ipsum quidem deleniti nisi sit voluptas. Ipsa provident placeat nostrum ea. Quas dolores velit iusto qui mollitia repellat. Placeat rerum odio dolor impedit omnis temporibus.', 'images.jpg'),
(6, 24, 'Tenetur molestiae quas.', 'Maxime et saepe corporis exercitationem perferendis. Ad velit nihil sed aperiam est ipsa. Nesciunt beatae dolorem ullam aut.', 'images.jpg'),
(7, 24, 'Fugit est tempore.', 'Velit nostrum illum sed expedita. Et id pariatur reprehenderit. Adipisci corrupti blanditiis quam porro corrupti.', 'images.jpg'),
(8, 23, 'Libero omnis corporis quia.', 'Cum ea dolores cum. Distinctio provident possimus ab quas sit. Aut pariatur eius libero voluptates ut. Aut et maxime nesciunt et omnis odit deleniti. Quia saepe quis qui tempore qui.', 'images.jpg'),
(9, 24, 'Qui quia reprehenderit quae.', 'Iste ad iste architecto. Porro aliquid rem magnam aperiam blanditiis dignissimos dolorem. Non quas autem vitae totam itaque molestiae qui.', 'images.jpg'),
(10, 24, 'Quo modi ut saepe.', 'Iste maiores laudantium quae ut molestiae animi dolorum. Placeat consectetur tempora neque sit dolore. Animi voluptatibus eligendi est. Quod in repellat quis expedita nihil ab assumenda.', 'images.jpg'),
(11, 23, 'Sint maiores atque.', 'Reprehenderit sed dolores autem in voluptas enim ipsam laboriosam. Et et exercitationem eum ex tempore nulla optio. Et eaque velit alias repudiandae. In dolores libero autem.', 'images.jpg'),
(12, 22, 'Sed quae velit.', 'Cumque itaque in et illum autem delectus. Libero minus molestias quia eius impedit rerum rerum.', 'images.jpg'),
(13, 22, 'Eos id velit.', 'Cupiditate ullam cupiditate ut non est corporis. Nihil quae corrupti dolor nam. Aut beatae cum aut dicta qui quas ratione.', 'images.jpg'),
(14, 21, 'Quaerat similique nostrum quis.', 'Modi adipisci nulla maxime minima odit amet. Dicta sed dolor aperiam nam incidunt error soluta. Facilis quia enim iure possimus sequi nihil. A incidunt sed voluptas eum praesentium.', 'images.jpg'),
(15, 23, 'Facere quam maxime et.', 'Pariatur sapiente sed veritatis unde sint temporibus. Voluptatem rerum delectus voluptas. Earum omnis voluptate saepe.', 'images.jpg'),
(16, 25, 'Tempore repudiandae dolorem quo ut.', 'Molestias ea corporis ea dignissimos non molestiae. Natus delectus aperiam in sapiente quas. Error voluptates vel modi ab. Ea et consequuntur velit id consequatur voluptatem.', 'images.jpg'),
(17, 24, 'Ut voluptas et.', 'Consectetur ut perspiciatis velit qui eum molestiae cum. Et dolore quibusdam animi voluptatem. Nesciunt aspernatur ut consequatur. Maxime dolore voluptatem sint aut dolor.', 'images.jpg'),
(18, 25, 'Nesciunt velit rem.', 'Laborum rerum aspernatur commodi explicabo iure ratione et. Sed maxime velit officia. Excepturi laborum placeat dolor nesciunt est inventore est. Laudantium voluptas voluptatem totam ipsam.', 'images.jpg'),
(19, 21, 'Incidunt eos distinctio.', 'Quo dolore ut sed ea delectus hic neque. Nihil qui dolores unde sunt molestiae quis. Minus qui ipsum rem occaecati fugiat dolorem. Enim fugit qui doloremque deserunt.', 'images.jpg'),
(20, 24, 'Odio modi.', 'Voluptatem ipsum commodi fugit numquam sit laboriosam. Est officia nihil qui. Perferendis voluptatem pariatur id culpa doloremque et.', 'images.jpg'),
(21, 25, 'Eligendi repudiandae ex.', 'Vero et labore eos distinctio nemo iusto. Maiores nihil non eos sed expedita. Accusantium beatae voluptatum ipsum sed eligendi. Repellat quod iure et quas et eveniet.', 'images.jpg'),
(22, 25, 'Pariatur in voluptates.', 'Iste ut quia repellendus. Et eius et aut nobis quia culpa nemo. Ipsa et nihil dolore qui labore. Nam doloribus voluptates ducimus error sapiente consequatur est.', 'images.jpg'),
(23, 25, 'Voluptas tempore expedita possimus non.', 'Exercitationem veniam laboriosam et dignissimos. Quo et saepe voluptatum inventore minus incidunt rem. Sed vitae dolorem repellendus consequatur quo.', 'images.jpg'),
(24, 21, 'Est nostrum numquam.', 'Ipsam omnis aperiam veritatis id ut. Quia sed cupiditate ipsa veniam. Voluptas aperiam quia sequi.', 'images.jpg'),
(25, 21, 'Officiis ut odit aspernatur.', 'Enim id est quibusdam vitae voluptatem reiciendis. Est est tenetur eos quaerat enim est.', 'images.jpg'),
(26, 24, 'Autem quod in sit.', 'Nulla perspiciatis vel pariatur sapiente reprehenderit sed distinctio. Voluptatem ut officiis et et accusamus ullam. Debitis vitae dolorem error nulla voluptate aut pariatur et.', 'images.jpg'),
(27, 25, 'Voluptatum possimus unde ipsam.', 'Impedit adipisci deserunt et sed quo vero architecto. Nulla eum quia incidunt architecto. Consequatur nam rerum omnis illum. Sit dolores quod voluptas maxime rerum unde qui.', 'images.jpg'),
(28, 22, 'Est enim ut in.', 'Suscipit itaque rerum commodi soluta quas ut. Illo iure voluptas in itaque quos dolor nisi. Quidem facere quod et nesciunt maiores accusantium.', 'images.jpg'),
(29, 24, 'Dicta deleniti aut voluptate.', 'Exercitationem repellendus laboriosam velit dolores excepturi nam. Sunt assumenda quisquam rerum velit atque. Molestiae mollitia eius sit dolores maxime quas occaecati.', 'images.jpg'),
(30, 24, 'In quas debitis.', 'Voluptate iusto quo quibusdam dolor consequatur. Illum rerum ab ut alias quia quia vel.', 'images.jpg'),
(31, 23, 'Reiciendis ipsa ex in.', 'Eum vero molestiae aperiam reiciendis eveniet et. Dolorum magnam blanditiis dicta quaerat. Quaerat quisquam voluptas omnis est.', 'images.jpg'),
(32, 23, 'Perspiciatis reiciendis.', 'Consequatur et sit sit quia facilis omnis. Distinctio optio ut ratione doloremque rerum quia totam eaque.', 'images.jpg'),
(33, 22, 'Eius perferendis dolor.', 'Modi modi nisi voluptatem eligendi voluptas enim omnis. Aut excepturi suscipit qui tempora dolorem doloribus. Alias repudiandae laboriosam sit dolorem quasi nam.', 'images.jpg'),
(34, 24, 'Dolores et maiores dignissimos.', 'Maiores in et expedita aut cum. Quod hic ex voluptas. Qui est non magnam sit ut voluptatum asperiores. Velit incidunt autem voluptas quod aut voluptas molestiae.', 'images.jpg'),
(35, 23, 'Nobis ipsum illo necessitatibus.', 'Dignissimos et maiores ad. Facere autem et id qui eum praesentium molestias qui. Vitae voluptatem quis incidunt excepturi. Porro nulla tempore molestiae quo id.', 'images.jpg'),
(36, 25, 'Quidem quibusdam error voluptas.', 'Non earum et ipsam optio pariatur aut. Provident optio quibusdam eius autem eius voluptatem est. Facilis culpa fugiat amet rerum saepe a possimus est. Eos aspernatur consequatur rem.', 'images.jpg'),
(37, 24, 'Suscipit sit maxime consequatur inventore.', 'Voluptatem ut eum sint. Aperiam quas sunt dolorem corrupti qui et. Officia soluta reprehenderit ut aut et recusandae eos. Mollitia ut non aut doloribus et sint.', 'images.jpg'),
(38, 25, 'At in debitis cumque est.', 'Nostrum sed accusantium eaque explicabo maxime placeat. Perferendis laboriosam earum libero ea.', 'images.jpg'),
(39, 22, 'Quo et itaque.', 'Ex totam totam voluptas nihil ut nisi et. Qui minus dolorum laboriosam qui aut non est. Facilis ullam nihil consequatur.', 'images.jpg'),
(40, 22, 'Ratione soluta molestias maxime.', 'Officia ad possimus error soluta et. Sint aut dolorem labore provident rerum quo. Odit cum et necessitatibus hic. Nostrum molestias veritatis nihil qui.', 'images.jpg'),
(41, 21, 'Odio assumenda corporis ut suscipit.', 'Atque nihil reiciendis omnis optio. Est ut sequi ea sunt culpa esse ipsa. Illo et et voluptatem eum esse unde. Cupiditate voluptas optio similique amet quos.', 'images.jpg'),
(42, 22, 'Exercitationem architecto laudantium.', 'Vel dolorum est minima cupiditate. Ipsa inventore ullam perspiciatis repudiandae minima. Autem ex aut id accusamus hic. Sit facilis ut aliquam inventore.', 'images.jpg'),
(43, 24, 'Eum quas ea suscipit.', 'Quaerat consectetur ipsa consequatur id. Velit veritatis consequatur labore natus rerum omnis. Asperiores nihil voluptates cum et in eaque doloremque.', 'images.jpg'),
(44, 23, 'Quasi quos voluptatibus.', 'Natus quia sed ut facere ipsum. Quibusdam dolores quos labore. Dolores velit molestiae ipsum quo. Est similique accusantium hic maxime ullam.', 'images.jpg'),
(45, 22, 'Labore voluptas est.', 'Neque dolor voluptatem ea quae qui et. Similique ipsa asperiores quaerat est ipsam itaque enim. Qui doloremque quisquam qui suscipit ex laboriosam.', 'images.jpg'),
(46, 25, 'Quod consequatur minima.', 'Suscipit ducimus libero autem voluptas quo tempora animi. Doloribus quidem ducimus aut dolorem aut nostrum. Aut excepturi quidem ullam et dolor. Quisquam dolores libero qui in.', 'images.jpg'),
(47, 24, 'Quis nesciunt quia.', 'Cum aut autem adipisci doloribus deleniti eveniet aut. Qui culpa ratione minima omnis. Ullam vel voluptas numquam voluptatem provident numquam ullam. Tempore id aut accusamus omnis molestiae.', 'images.jpg'),
(48, 25, 'Qui aspernatur ab.', 'Fuga veritatis nemo nulla rem hic qui. Ad harum voluptatibus accusamus officiis sit quasi unde. Perspiciatis laborum vel ut minus.', 'images.jpg'),
(49, 22, 'Distinctio quis suscipit aut.', 'Rerum ipsa minima dolores dignissimos. Quasi similique ut saepe neque assumenda. Perferendis qui harum excepturi sint non voluptas.', 'images.jpg'),
(50, 25, 'Expedita aut dolorum.', 'Quia vero et quod pariatur. Voluptas eos distinctio corporis enim aut ut est. Et eum laudantium officiis nemo libero molestiae fuga dolorem. Qui deserunt et ipsam.', 'images.jpg'),
(51, NULL, 'test', 'egrg', 'C:\\xampp\\tmp\\php46C5.tmp'),
(52, NULL, 'test', 'ezfzffez', 'C:\\xampp\\tmp\\php2A6F.tmp'),
(53, NULL, 'efzef', 'supeerrrr', 'C:\\xampp\\tmp\\php86CF.tmp'),
(54, NULL, 'test', 'zqht', 'C:\\xampp\\tmp\\phpCA4A.tmp');

-- --------------------------------------------------------

--
-- Structure de la table `continent`
--

CREATE TABLE `continent` (
  `id` int(11) NOT NULL,
  `name_continent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `continent`
--

INSERT INTO `continent` (`id`, `name_continent`) VALUES
(21, 'Autem ea pariatur non.'),
(22, 'Et esse repudiandae.'),
(23, 'Provident qui aut aperiam.'),
(24, 'Vitae debitis omnis.'),
(25, 'A nemo fugiat.');

-- --------------------------------------------------------

--
-- Structure de la table `migration_versions`
--

CREATE TABLE `migration_versions` (
  `version` varchar(14) COLLATE utf8mb4_unicode_ci NOT NULL,
  `executed_at` datetime NOT NULL COMMENT '(DC2Type:datetime_immutable)'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `migration_versions`
--

INSERT INTO `migration_versions` (`version`, `executed_at`) VALUES
('20200305100956', '2020-03-05 10:10:03');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `article`
--
ALTER TABLE `article`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_23A0E66E63BB68B` (`continent_id_id`);

--
-- Index pour la table `continent`
--
ALTER TABLE `continent`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `migration_versions`
--
ALTER TABLE `migration_versions`
  ADD PRIMARY KEY (`version`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `article`
--
ALTER TABLE `article`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;

--
-- AUTO_INCREMENT pour la table `continent`
--
ALTER TABLE `continent`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `article`
--
ALTER TABLE `article`
  ADD CONSTRAINT `FK_23A0E66E63BB68B` FOREIGN KEY (`continent_id_id`) REFERENCES `continent` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
