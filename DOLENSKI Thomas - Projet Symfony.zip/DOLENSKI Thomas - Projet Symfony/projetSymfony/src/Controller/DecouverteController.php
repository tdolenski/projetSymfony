<?php

namespace App\Controller;

use App\Entity\Article;
use App\Form\DecouverteType;
use App\Repository\ArticleRepository;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;




class DecouverteController extends AbstractController
{
    /**
     * @Route("/decouverte", name="decouverte.index")
     */
    public function index(ArticleRepository $articleRepository)
    {
         $results = $articleRepository->findAll();
       
        return $this->render('decouverte/index.html.twig', [
            'results' => $results
        ]);
    }

   
    
    /**
     * @Route("/decouverte/form", name="decouverte.form")
     */

    public function form(Request $request, EntityManagerInterface $entityManager, int $id = null, ArticleRepository $decouverteRepository): Response
    {
        //affichage d'un formulaire
        $type = DecouverteType::class;
        $model = $id ? $decouverteRepository->find($id) : new Article();

        $form = $this->createForm($type, $model);
        $form->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()) {
            //dd($model);

            $entityManager->persist($model);
            $id ? null : $entityManager->persist($model);
            $entityManager->flush();
            //message de confirmation
            $message = $id ? "le produit a été modifié " : "lE PRODUit a été ajouté";
            $this->addFlash('notice', $message);
            //redirection
            $this->redirectToRoute('decouverte.index');
        }
        return $this->render('decouverte/form.html.twig', [
            'form' => $form->createView()
        ]);
    }
     
     /**
	 * @Route("/decouverte/{id}", name="decouverte.details")
     */
	public function details(int $id, ArticleRepository $articleRepository):Response
	{
		$article = $articleRepository->find($id);
		return $this->render('decouverte/details.html.twig', [
			'article' => $article
		]);
    }
    
    
}
