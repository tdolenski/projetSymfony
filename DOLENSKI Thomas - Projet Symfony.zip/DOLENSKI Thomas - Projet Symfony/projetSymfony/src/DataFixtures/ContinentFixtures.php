<?php

namespace App\DataFixtures;

use App\Entity\Continent;
use Faker\Factory as Faker;
use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Common\Persistence\ObjectManager;
use Doctrine\Common\DataFixtures\DependentFixtureInterface;

class ContinentFixtures extends Fixture /*implements DependentFixtureInterface*/
{
    public function load(ObjectManager $manager)
    {
    	$faker = Faker::create();

    	// création de plusieurs articles
	    for($i = 0; $i < 5; $i++) {
	    	// instanciation d'une entité
		    $continent = new Continent();
			$continent->setNameContinent( $faker->sentence(3) );
			
			$this->addReference("continent$i", $continent);

		    // doctrine : méthode persist permet de créer un enregistrement (INSERT INTO)
		    $manager->persist($continent);
	    }

	    // doctrine : méthode flush permet d'exécuter les requêtes SQL (à exécuter une seule fois)
        $manager->flush();
    }

   /* public function getDependencies(){
        return [
           
        ];
    }*/
}
