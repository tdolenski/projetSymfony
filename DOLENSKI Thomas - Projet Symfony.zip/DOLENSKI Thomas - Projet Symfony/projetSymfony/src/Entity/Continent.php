<?php

namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass="App\Repository\ContinentRepository")
 */
class Continent
{
    /**
     * @ORM\Id()
     * @ORM\GeneratedValue()
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $name_continent;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getNameContinent(): ?string
    {
        return $this->name_continent;
    }

    public function setNameContinent(string $name_continent): self
    {
        $this->name_continent = $name_continent;

        return $this;
    }
}
