<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* contact/index.html.twig */
class __TwigTemplate_7c7a8b1fc6b13e9a1f597f77627fc3c2b433ac8111d90b38f2996802677ff839 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "contact/index.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "contact/index.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "contact/index.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "\t<div class=\"row\">
\t\t<div class=\"col\">
\t\t\t<h1>Contact</h1>
\t\t\t";
        // line 25
        echo "\t\t\t";
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 25, $this->source); })()), 'form_start', ["attr" => ["novalidate" => "novalidate"]]);
        echo "
\t\t\t\t<p>
\t\t\t\t\t";
        // line 27
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 27, $this->source); })()), "firstname", [], "any", false, false, false, 27), 'label', ["label" => "Prénom:"]);
        echo "
\t\t\t\t\t";
        // line 28
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 28, $this->source); })()), "firstname", [], "any", false, false, false, 28), 'widget', ["attr" => ["placeholder" => "Saisissez votre prénom", "autofocus" => "autofocus"]]);
        // line 35
        echo "
\t\t\t\t</p>
\t\t\t\t<p>
\t\t\t\t\t";
        // line 38
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 38, $this->source); })()), "lastname", [], "any", false, false, false, 38), 'label', ["label" => "Nom:"]);
        echo "
\t\t\t\t\t";
        // line 39
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 39, $this->source); })()), "lastname", [], "any", false, false, false, 39), 'widget');
        echo "
\t\t\t\t</p>
\t\t\t\t<p>
\t\t\t\t\t";
        // line 42
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 42, $this->source); })()), "email", [], "any", false, false, false, 42), 'label', ["label" => "Email:"]);
        echo "
\t\t\t\t\t";
        // line 43
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 43, $this->source); })()), "email", [], "any", false, false, false, 43), 'widget');
        echo "
\t\t\t\t</p>
\t\t\t\t<p>
\t\t\t\t\t";
        // line 46
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 46, $this->source); })()), "message", [], "any", false, false, false, 46), 'label', ["label" => "Message:"]);
        echo "
\t\t\t\t\t";
        // line 47
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 47, $this->source); })()), "message", [], "any", false, false, false, 47), 'widget');
        echo "
\t\t\t\t</p>
\t\t\t\t<p>
\t\t\t\t\t<input type=\"submit\" value=\"Valider\" class=\"btn btn-primary\">
\t\t\t\t</p>
\t\t\t";
        // line 52
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 52, $this->source); })()), 'form_end');
        echo "
\t\t</div>
\t</div>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "contact/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  122 => 52,  114 => 47,  110 => 46,  104 => 43,  100 => 42,  94 => 39,  90 => 38,  85 => 35,  83 => 28,  79 => 27,  73 => 25,  68 => 4,  58 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}

{%  block body %}
\t<div class=\"row\">
\t\t<div class=\"col\">
\t\t\t<h1>Contact</h1>
\t\t\t{#
\t\t\t\tfonctions twig de formulaire
\t\t\t\t\tform_start: crée la balise <form>
\t\t\t\t\tform_end: ferme la balise <form>
\t\t\t\t\tform_label: crée un intitulé de champ de saisie, <label>
\t\t\t\t\t\tnom du champ défini dans la classe de formulaire (src/Form/ContactType)
\t\t\t\t\t\ttexte de l'intitulé
\t\t\t\t\tform_widget: crée le champ de saisie
\t\t\t\t\t\tnom du champ défini dans la classe de formulaire (src/Form/ContactType)
\t\t\t\tla variable form est envoyée par le contrôleur
\t\t\t\tle nom des champs de saisie est défini dans la classe de formulaire (src/Form/ContactType)
\t\t\t\til est nécessaire de créer le bouton de validation du formulaire
\t\t\t\tpour appliquer le thème bootstrap à tous les formulaires
\t\t\t\t\tajouter la clé form_themes dans config/packages/twig.yaml
\t\t\t\tpour ajouter des attributs HTML aux champs de saisie,
\t\t\t\t\tutiliser le second paramètre de form_widget avec la clé attr (attributs)
\t\t\t\tdésactiver la validation html, ajouter l'attribut novalidate sur la balise <form>
\t\t\t#}
\t\t\t{{ form_start(form, { attr: { novalidate: 'novalidate' } }) }}
\t\t\t\t<p>
\t\t\t\t\t{{ form_label(form.firstname, 'Prénom:') }}
\t\t\t\t\t{{ form_widget(form.firstname,
\t\t\t\t\t\t{ attr:
\t\t\t\t\t\t\t{
\t\t\t\t\t\t\t\tplaceholder: 'Saisissez votre prénom',
\t\t\t\t\t\t\t\tautofocus: 'autofocus'
\t\t\t\t\t\t\t}
\t\t\t\t\t\t}
\t\t\t\t\t) }}
\t\t\t\t</p>
\t\t\t\t<p>
\t\t\t\t\t{{ form_label(form.lastname, 'Nom:') }}
\t\t\t\t\t{{ form_widget(form.lastname) }}
\t\t\t\t</p>
\t\t\t\t<p>
\t\t\t\t\t{{ form_label(form.email, 'Email:') }}
\t\t\t\t\t{{ form_widget(form.email) }}
\t\t\t\t</p>
\t\t\t\t<p>
\t\t\t\t\t{{ form_label(form.message, 'Message:') }}
\t\t\t\t\t{{ form_widget(form.message) }}
\t\t\t\t</p>
\t\t\t\t<p>
\t\t\t\t\t<input type=\"submit\" value=\"Valider\" class=\"btn btn-primary\">
\t\t\t\t</p>
\t\t\t{{ form_end(form) }}
\t\t</div>
\t</div>
{%  endblock %}
", "contact/index.html.twig", "C:\\Users\\thoma\\Desktop\\projetSymfony\\templates\\contact\\index.html.twig");
    }
}
