<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _inc/pagination.html.twig */
class __TwigTemplate_90da9cbd4ba8f5dd9d250782992a340705502a9181d11eccdaa9d7cdab8b6597 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "_inc/pagination.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "_inc/pagination.html.twig"));

        // line 1
        $context["nb_pages"] = twig_round(((isset($context["total_items"]) || array_key_exists("total_items", $context) ? $context["total_items"] : (function () { throw new RuntimeError('Variable "total_items" does not exist.', 1, $this->source); })()) / (isset($context["items_per_page"]) || array_key_exists("items_per_page", $context) ? $context["items_per_page"] : (function () { throw new RuntimeError('Variable "items_per_page" does not exist.', 1, $this->source); })())), 0, "ceil");
        // line 2
        $context["active_page"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 2, $this->source); })()), "request", [], "any", false, false, false, 2), "get", [0 => "_route_params"], "method", false, false, false, 2), "page", [], "array", false, false, false, 2);
        // line 3
        echo "
<div class=\"row\">
\t<div class=\"col\">
\t\t<nav aria-label=\"Page navigation example\">
\t\t\t<ul class=\"pagination justify-content-center\">
\t\t\t\t<li class=\"page-item ";
        // line 8
        echo ((0 === twig_compare((isset($context["active_page"]) || array_key_exists("active_page", $context) ? $context["active_page"] : (function () { throw new RuntimeError('Variable "active_page" does not exist.', 8, $this->source); })()), 1)) ? ("disabled") : (null));
        echo "\">
\t\t\t\t\t<a class=\"page-link\" href=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getUrl((isset($context["route_name"]) || array_key_exists("route_name", $context) ? $context["route_name"] : (function () { throw new RuntimeError('Variable "route_name" does not exist.', 9, $this->source); })()), ["page" => ((isset($context["active_page"]) || array_key_exists("active_page", $context) ? $context["active_page"] : (function () { throw new RuntimeError('Variable "active_page" does not exist.', 9, $this->source); })()) - 1)]), "html", null, true);
        echo "\" aria-label=\"Previous\">
\t\t\t\t\t\t<span aria-hidden=\"true\">&laquo;</span>
\t\t\t\t\t</a>
\t\t\t\t</li>
\t\t\t\t";
        // line 13
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(range(1, (isset($context["nb_pages"]) || array_key_exists("nb_pages", $context) ? $context["nb_pages"] : (function () { throw new RuntimeError('Variable "nb_pages" does not exist.', 13, $this->source); })())));
        foreach ($context['_seq'] as $context["_key"] => $context["i"]) {
            // line 14
            echo "\t\t\t\t\t<li class=\"page-item ";
            echo ((0 === twig_compare((isset($context["active_page"]) || array_key_exists("active_page", $context) ? $context["active_page"] : (function () { throw new RuntimeError('Variable "active_page" does not exist.', 14, $this->source); })()), $context["i"])) ? ("active") : (null));
            echo "\">
\t\t\t\t\t\t<a class=\"page-link\" href=\"";
            // line 15
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getUrl((isset($context["route_name"]) || array_key_exists("route_name", $context) ? $context["route_name"] : (function () { throw new RuntimeError('Variable "route_name" does not exist.', 15, $this->source); })()), ["page" => $context["i"]]), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $context["i"], "html", null, true);
            echo "</a>
\t\t\t\t\t</li>
\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['i'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 18
        echo "\t\t\t\t<li class=\"page-item ";
        echo ((0 === twig_compare((isset($context["active_page"]) || array_key_exists("active_page", $context) ? $context["active_page"] : (function () { throw new RuntimeError('Variable "active_page" does not exist.', 18, $this->source); })()), (isset($context["nb_pages"]) || array_key_exists("nb_pages", $context) ? $context["nb_pages"] : (function () { throw new RuntimeError('Variable "nb_pages" does not exist.', 18, $this->source); })()))) ? ("disabled") : (null));
        echo "\">
\t\t\t\t\t<a class=\"page-link\" href=\"";
        // line 19
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getUrl((isset($context["route_name"]) || array_key_exists("route_name", $context) ? $context["route_name"] : (function () { throw new RuntimeError('Variable "route_name" does not exist.', 19, $this->source); })()), ["page" => ((isset($context["active_page"]) || array_key_exists("active_page", $context) ? $context["active_page"] : (function () { throw new RuntimeError('Variable "active_page" does not exist.', 19, $this->source); })()) + 1)]), "html", null, true);
        echo "\" aria-label=\"Next\">
\t\t\t\t\t\t<span aria-hidden=\"true\">&raquo;</span>
\t\t\t\t\t</a>
\t\t\t\t</li>
\t\t\t</ul>
\t\t</nav>
\t</div>
</div>";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "_inc/pagination.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  90 => 19,  85 => 18,  74 => 15,  69 => 14,  65 => 13,  58 => 9,  54 => 8,  47 => 3,  45 => 2,  43 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% set nb_pages = (total_items / items_per_page) | round(0, 'ceil') %}
{% set active_page = app.request.get('_route_params')['page'] %}

<div class=\"row\">
\t<div class=\"col\">
\t\t<nav aria-label=\"Page navigation example\">
\t\t\t<ul class=\"pagination justify-content-center\">
\t\t\t\t<li class=\"page-item {{ active_page == 1 ? 'disabled' : null }}\">
\t\t\t\t\t<a class=\"page-link\" href=\"{{ url(route_name, { page: active_page - 1 }) }}\" aria-label=\"Previous\">
\t\t\t\t\t\t<span aria-hidden=\"true\">&laquo;</span>
\t\t\t\t\t</a>
\t\t\t\t</li>
\t\t\t\t{% for i in 1..nb_pages %}
\t\t\t\t\t<li class=\"page-item {{ active_page == i ? 'active' : null }}\">
\t\t\t\t\t\t<a class=\"page-link\" href=\"{{ url(route_name, { page: i }) }}\">{{ i }}</a>
\t\t\t\t\t</li>
\t\t\t\t{% endfor %}
\t\t\t\t<li class=\"page-item {{ active_page == nb_pages ? 'disabled' : null }}\">
\t\t\t\t\t<a class=\"page-link\" href=\"{{ url(route_name, { page: active_page + 1 }) }}\" aria-label=\"Next\">
\t\t\t\t\t\t<span aria-hidden=\"true\">&raquo;</span>
\t\t\t\t\t</a>
\t\t\t\t</li>
\t\t\t</ul>
\t\t</nav>
\t</div>
</div>", "_inc/pagination.html.twig", "C:\\Users\\thoma\\Desktop\\projetSymfony\\templates\\_inc\\pagination.html.twig");
    }
}
