<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _inc/nav.html.twig */
class __TwigTemplate_807d7d2b63c1df1679bbf03797042e25d672011d34145574db8c57d88831201e extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "_inc/nav.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "_inc/nav.html.twig"));

        // line 1
        echo "<nav class=\"navbar navbar-expand-lg navbar-light bg-light\">
\t<button class=\"navbar-toggler\" type=\"button\" data-toggle=\"collapse\" data-target=\"#navbarTogglerDemo01\" aria-controls=\"navbarTogglerDemo01\" aria-expanded=\"false\" aria-label=\"Toggle navigation\">
\t\t<span class=\"navbar-toggler-icon\"></span>
\t</button>
\t<div class=\"collapse navbar-collapse\" id=\"navbarTogglerDemo01\">
\t\t<a class=\"navbar-brand\" href=\"";
        // line 6
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getUrl("homepage.index");
        echo "\">My Website</a>
\t\t<ul class=\"navbar-nav mr-auto mt-2 mt-lg-0\">
\t\t\t<li class=\"nav-item active\">
\t\t\t\t<a class=\"nav-link\" href=\"";
        // line 9
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getUrl("homepage.index");
        echo "\">Home</a>
\t\t\t</li>
\t\t\t<li class=\"nav-item\">
\t\t\t\t<a class=\"nav-link\" href=\"";
        // line 12
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getUrl("decouverte.index");
        echo "\">Découverte</a>
\t\t\t</li>
\t\t\t<li class=\"nav-item\">
\t\t\t\t<a class=\"nav-link\" href=\"";
        // line 15
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getUrl("contact.index");
        echo "\">Contact</a>
\t\t\t</li>
\t\t\t<!--<li class=\"nav-item\">
\t\t\t\t<a class=\"nav-link\" href=\"";
        // line 18
        echo "\">Products</a>
\t\t\t</li>-->
\t\t\t";
        // line 26
        echo "\t\t\t";
        // line 27
        echo "\t\t\t\t<li class=\"nav-item\">
\t\t\t\t\t<a class=\"nav-link\" href=\"";
        // line 28
        echo "\">Administration</a>
\t\t\t\t</li>
\t\t\t";
        // line 31
        echo "\t\t</ul>
\t\t";
        // line 36
        echo "\t</div>
</nav>";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "_inc/nav.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  90 => 36,  87 => 31,  83 => 28,  80 => 27,  78 => 26,  74 => 18,  68 => 15,  62 => 12,  56 => 9,  50 => 6,  43 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<nav class=\"navbar navbar-expand-lg navbar-light bg-light\">
\t<button class=\"navbar-toggler\" type=\"button\" data-toggle=\"collapse\" data-target=\"#navbarTogglerDemo01\" aria-controls=\"navbarTogglerDemo01\" aria-expanded=\"false\" aria-label=\"Toggle navigation\">
\t\t<span class=\"navbar-toggler-icon\"></span>
\t</button>
\t<div class=\"collapse navbar-collapse\" id=\"navbarTogglerDemo01\">
\t\t<a class=\"navbar-brand\" href=\"{{ url('homepage.index') }}\">My Website</a>
\t\t<ul class=\"navbar-nav mr-auto mt-2 mt-lg-0\">
\t\t\t<li class=\"nav-item active\">
\t\t\t\t<a class=\"nav-link\" href=\"{{ url('homepage.index') }}\">Home</a>
\t\t\t</li>
\t\t\t<li class=\"nav-item\">
\t\t\t\t<a class=\"nav-link\" href=\"{{ url('decouverte.index') }}\">Découverte</a>
\t\t\t</li>
\t\t\t<li class=\"nav-item\">
\t\t\t\t<a class=\"nav-link\" href=\"{{ url('contact.index') }}\">Contact</a>
\t\t\t</li>
\t\t\t<!--<li class=\"nav-item\">
\t\t\t\t<a class=\"nav-link\" href=\"{#{ url('product.index') }#}\">Products</a>
\t\t\t</li>-->
\t\t\t{#
\t\t\t\trécupérer les informations de l'utilisateur : app.user
\t\t\t\ttester le rôle de l'utilisateur : is_granted
\t\t\t\t\t- IS_AUTHENTICATED_FULLY : utilisateur connecté quelque soit son rôle
\t\t\t\t\t- IS_AUTHENTICATED_ANONYMOUSLY : utilisateur connecté en tant qu'anonyme
\t\t\t#}
\t\t\t{#% if is_granted('ROLE_ADMIN') %#}
\t\t\t\t<li class=\"nav-item\">
\t\t\t\t\t<a class=\"nav-link\" href=\"{#{ url('admin.homepage.index') }#}\">Administration</a>
\t\t\t\t</li>
\t\t\t{#% endif %#}
\t\t</ul>
\t\t{#<form class=\"form-inline my-2 my-lg-0\" method=\"post\" action=\"{{ url('search.index') }}\">
\t\t\t<input class=\"form-control mr-sm-2\" type=\"search\" placeholder=\"Search\" aria-label=\"Search\" name=\"search\">
\t\t\t<button class=\"btn btn-outline-success my-2 my-sm-0\" type=\"submit\">Search</button>
\t\t</form>#}
\t</div>
</nav>", "_inc/nav.html.twig", "C:\\Users\\thoma\\Desktop\\projetSymfony\\templates\\_inc\\nav.html.twig");
    }
}
